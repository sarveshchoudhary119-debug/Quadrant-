package com.example.quadlauncher

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * Pick one app for each of four slots, then launch all four into the
 * four quadrants of the screen using freeform window bounds.
 */
class MainActivity : AppCompatActivity() {

    private data class AppInfo(val label: String, val pkg: String, val icon: Drawable)

    private val prefs by lazy { getSharedPreferences("quad", Context.MODE_PRIVATE) }
    private val slotViews = arrayOfNulls<TextView>(4)
    private val slotNames = listOf("Top-left", "Top-right", "Bottom-left", "Bottom-right")
    private var apps: List<AppInfo> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        apps = loadApps()
        setContentView(buildUi())
        refreshSlots()
    }

    // ---------- UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(16))
        }

        root.addView(TextView(this).apply {
            text = "QuadLauncher"
            textSize = 24f
            setPadding(0, 0, 0, dp(4))
        })
        root.addView(TextView(this).apply {
            text = "Tap a quadrant to choose its app, then press Launch."
            setPadding(0, 0, 0, dp(12))
        })

        val grid = GridLayout(this).apply {
            rowCount = 2
            columnCount = 2
        }
        for (i in 0 until 4) {
            val tv = TextView(this).apply {
                gravity = Gravity.CENTER
                textSize = 16f
                setPadding(dp(8), dp(8), dp(8), dp(8))
                setBackgroundResource(android.R.drawable.dialog_holo_light_frame)
                setOnClickListener { pickApp(i) }
            }
            slotViews[i] = tv
            grid.addView(tv, GridLayout.LayoutParams(
                GridLayout.spec(i / 2, 1f), GridLayout.spec(i % 2, 1f)
            ).apply {
                width = 0
                height = dp(140)
                setMargins(dp(4), dp(4), dp(4), dp(4))
            })
        }
        root.addView(grid, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(Button(this).apply {
            text = "Launch all four"
            setOnClickListener { launchAll() }
        })
        root.addView(Button(this).apply {
            text = "Open developer settings (enable freeform)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
            }
        })
        root.addView(TextView(this).apply {
            text = "If apps open full-screen instead of in quadrants, turn on " +
                "\"Enable freeform windows\" and \"Force activities to be resizable\" " +
                "in Developer options, then reboot."
            textSize = 12f
            setPadding(0, dp(12), 0, 0)
        })
        return ScrollView(this).apply { addView(root) }
    }

    private fun refreshSlots() {
        for (i in 0 until 4) {
            val pkg = prefs.getString("slot$i", null)
            val app = apps.firstOrNull { it.pkg == pkg }
            slotViews[i]?.apply {
                text = "${slotNames[i]}\n" + (app?.label ?: "(tap to choose)")
                setCompoundDrawablesWithIntrinsicBounds(null, app?.icon?.let { scaled(it) }, null, null)
            }
        }
    }

    private fun scaled(d: Drawable): Drawable {
        d.setBounds(0, 0, dp(40), dp(40))
        return d
    }

    // ---------- App picking ----------

    private fun loadApps(): List<AppInfo> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm))
            }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    private fun pickApp(slot: Int) {
        val adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(p: Int) = apps[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, convert: View?, parent: ViewGroup): View {
                val tv = (convert as? TextView) ?: TextView(this@MainActivity).apply {
                    setPadding(dp(16), dp(12), dp(16), dp(12))
                    compoundDrawablePadding = dp(12)
                    gravity = Gravity.CENTER_VERTICAL
                }
                val a = apps[p]
                tv.text = a.label
                tv.setCompoundDrawablesWithIntrinsicBounds(scaled(a.icon), null, null, null)
                return tv
            }
        }
        AlertDialog.Builder(this)
            .setTitle("App for ${slotNames[slot]}")
            .setAdapter(adapter) { _, which ->
                prefs.edit().putString("slot$slot", apps[which].pkg).apply()
                refreshSlots()
            }
            .setNegativeButton("Clear") { _, _ ->
                prefs.edit().remove("slot$slot").apply()
                refreshSlots()
            }
            .show()
    }

    // ---------- Launching ----------

    private fun launchAll() {
        val screen = windowManager.currentWindowMetrics.bounds
        val halfW = screen.width() / 2
        val halfH = screen.height() / 2
        val quadrants = listOf(
            Rect(screen.left, screen.top, screen.left + halfW, screen.top + halfH),
            Rect(screen.left + halfW, screen.top, screen.right, screen.top + halfH),
            Rect(screen.left, screen.top + halfH, screen.left + halfW, screen.bottom),
            Rect(screen.left + halfW, screen.top + halfH, screen.right, screen.bottom)
        )

        var launched = 0
        for (i in 0 until 4) {
            val pkg = prefs.getString("slot$i", null) ?: continue
            val intent = packageManager.getLaunchIntentForPackage(pkg) ?: continue
            intent.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_MULTIPLE_TASK or
                    Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT
            )
            val options = ActivityOptions.makeBasic().setLaunchBounds(quadrants[i])
            try {
                startActivity(intent, options.toBundle())
                launched++
            } catch (e: Exception) {
                Toast.makeText(this, "Couldn't open ${slotNames[i]}: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
        if (launched == 0) {
            Toast.makeText(this, "Choose at least one app first", Toast.LENGTH_SHORT).show()
        }
    }
}
