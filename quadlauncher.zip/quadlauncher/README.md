# QuadLauncher

Pick four apps, launch them into the four quadrants of the screen.

## Get the APK without Android Studio (works from a phone browser)
1. Create a free GitHub account and a new repository.
2. Upload the contents of this folder (including the hidden `.github` folder).
3. Open the repo's **Actions** tab > **Build APK** > **Run workflow**.
4. When it finishes (a few minutes), open the run and download the
   **QuadLauncher-apk** artifact. Unzip it to get `app-debug.apk`.
5. Open the APK on your phone and allow "Install unknown apps" when asked.

## Build locally instead
1. Open this folder in Android Studio (Koala or newer) and let Gradle sync.
2. Run on a device, or Build > Build APK(s) to get `app-debug.apk`.

## One-time device setup (required)
Android only lets normal apps place other apps' windows when freeform
windowing is on:

1. Settings > About phone > tap Build number 7 times (enables Developer options).
2. Developer options > turn on **Enable freeform windows**
   and **Force activities to be resizable**.
3. Reboot.

Or over adb:

    adb shell settings put global enable_freeform_support 1
    adb shell settings put global force_resizable_activities 1
    adb reboot

## Use
Tap each quadrant, choose an app, press **Launch all four**.

## Limits
- Some apps refuse to resize or block multi-window and will open full-screen.
- Freeform windows can be dragged/resized afterward; quadrants are only the
  starting position.
- Behaviour varies by manufacturer (Samsung, Xiaomi etc. have their own
  multi-window rules).
